
import { Component, inject, signal, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { StoreService, User } from '../services/store.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="bg-slate-50 min-h-screen py-10">
      <div class="container mx-auto px-4 max-w-4xl">
        
        <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          
          <!-- Header Banner -->
          <div class="h-32 bg-gradient-to-r from-brand-500 to-brand-600 relative">
             <button (click)="logout()" class="absolute top-4 right-4 bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-lg text-sm font-medium backdrop-blur-sm transition-colors">
               Sign Out
             </button>
          </div>

          <div class="px-8 pb-8">
            <!-- Profile Image & Name -->
            <div class="flex flex-col md:flex-row items-center md:items-end -mt-12 mb-8 gap-6">
              <div class="relative group">
                <img [src]="editData.image || 'https://via.placeholder.com/150'" class="w-32 h-32 rounded-full border-4 border-white shadow-lg bg-white object-cover">
                <label class="absolute inset-0 flex items-center justify-center bg-black/40 rounded-full opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer text-white text-xs font-bold">
                  Change
                  <input type="file" (change)="onFileSelected($event)" class="hidden" accept="image/*">
                </label>
              </div>
              
              <div class="text-center md:text-left flex-1">
                <h1 class="text-2xl font-bold text-slate-800">{{editData.name || 'User Name'}}</h1>
                <p class="text-slate-500">{{editData.email || 'email@example.com'}}</p>
                @if (editData.isDonor) {
                  <span class="inline-block mt-2 bg-red-100 text-red-600 text-xs font-bold px-3 py-1 rounded-full">Blood Donor</span>
                }
              </div>
              
              <button (click)="saveProfile()" [disabled]="!isDirty()" class="bg-brand-600 text-white px-6 py-2.5 rounded-lg font-bold shadow-md hover:bg-brand-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all">
                Save Changes
              </button>
            </div>

            <!-- Edit Form -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div class="space-y-4">
                <h3 class="font-bold text-slate-800 border-b pb-2">Personal Information</h3>
                
                <div>
                  <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Full Name</label>
                  <input type="text" [(ngModel)]="editData.name" (input)="markDirty()" class="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 focus:ring-brand-500 focus:outline-none">
                </div>

                <div>
                  <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Phone Number</label>
                  <input type="tel" [(ngModel)]="editData.phone" (input)="markDirty()" class="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 focus:ring-brand-500 focus:outline-none">
                </div>

                <div>
                  <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Blood Group</label>
                  <select [(ngModel)]="editData.bloodGroup" (change)="markDirty()" class="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 focus:ring-brand-500 focus:outline-none">
                    <option value="" disabled>Select Group</option>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                  </select>
                </div>
              </div>

              <div class="space-y-4">
                <h3 class="font-bold text-slate-800 border-b pb-2">Delivery Details</h3>
                
                <div>
                  <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Email Address</label>
                  <input type="email" [(ngModel)]="editData.email" (input)="markDirty()" class="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 focus:ring-brand-500 focus:outline-none">
                </div>

                <div>
                  <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Default Address</label>
                  <textarea rows="4" [(ngModel)]="editData.address" (input)="markDirty()" class="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 focus:ring-brand-500 focus:outline-none" placeholder="House, Road, Area..."></textarea>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ProfilePage {
  store = inject(StoreService);
  router = inject(Router);

  editData: Partial<User> = {};
  isDirty = signal(false);

  constructor() {
    effect(() => {
      const user = this.store.currentUser();
      if (user) {
        this.editData = { ...user };
      }
    });
  }

  markDirty() {
    this.isDirty.set(true);
  }

  onFileSelected(event: any) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.editData.image = e.target.result;
        this.markDirty();
      };
      reader.readAsDataURL(file);
    }
  }

  saveProfile() {
    this.store.updateProfile(this.editData);
    this.isDirty.set(false);
    alert('Profile updated successfully!');
  }

  logout() {
    this.store.logout();
    this.router.navigate(['/']);
  }
}
