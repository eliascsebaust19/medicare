
import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { StoreService } from '../services/store.service';

@Component({
  selector: 'app-blood-donation',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="bg-slate-50 min-h-screen">
      <!-- Hero Section -->
      <div class="bg-medical-red text-white py-16">
        <div class="container mx-auto px-4 text-center">
          <h1 class="text-4xl md:text-5xl font-bold mb-4">Donate Blood, Save Life</h1>
          <p class="text-lg md:text-xl text-red-100 max-w-2xl mx-auto mb-8">
            Your single donation can save up to three lives. Join our community of heroes today or find a donor near you.
          </p>
          <button (click)="scrollToForm()" class="bg-white text-medical-red font-bold py-3 px-8 rounded-full hover:bg-red-50 transition-colors shadow-lg">
            Become a Donor
          </button>
        </div>
      </div>

      <div class="container mx-auto px-4 py-12 flex flex-col lg:flex-row gap-12">
        
        <!-- Donor Search & List -->
        <div class="flex-1">
          <h2 class="text-2xl font-bold text-slate-800 mb-6 flex items-center gap-2">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-medical-red" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            Find Blood Donors
          </h2>

          <!-- Search Filters -->
          <div class="bg-white p-4 rounded-xl shadow-sm border border-slate-100 mb-6 flex flex-col sm:flex-row gap-4">
             <select [(ngModel)]="selectedGroup" class="flex-1 p-2 bg-white text-slate-900 border border-slate-300 rounded-lg focus:ring-brand-500 focus:outline-none">
               <option value="All">All Blood Groups</option>
               <option value="A+">A+</option>
               <option value="A-">A-</option>
               <option value="B+">B+</option>
               <option value="B-">B-</option>
               <option value="O+">O+</option>
               <option value="O-">O-</option>
               <option value="AB+">AB+</option>
               <option value="AB-">AB-</option>
             </select>
             <input [(ngModel)]="locationSearch" placeholder="Search by Area (e.g. Dhanmondi)" class="flex-1 p-2 bg-white text-slate-900 border border-slate-300 rounded-lg focus:ring-brand-500 focus:outline-none placeholder-slate-400">
          </div>

          <!-- List -->
          <div class="grid grid-cols-1 gap-4">
            @for (donor of filteredDonors(); track donor.id) {
              <div class="bg-white p-5 rounded-xl shadow-sm border-l-4 border-medical-red flex items-center justify-between hover:shadow-md transition-shadow">
                <div>
                   <div class="flex items-center gap-2 mb-1">
                     <span class="font-bold text-slate-800 text-lg">{{donor.name}}</span>
                     <span class="bg-red-100 text-medical-red text-xs font-bold px-2 py-0.5 rounded-full">{{donor.bloodGroup}}</span>
                   </div>
                   <p class="text-slate-500 text-sm flex items-center gap-1">
                     <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
                     </svg>
                     {{donor.location}}
                   </p>
                </div>
                <a href="tel:{{donor.phone}}" class="bg-green-50 text-green-600 p-3 rounded-full hover:bg-green-100 transition-colors" title="Call Donor">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                </a>
              </div>
            }
            @if (filteredDonors().length === 0) {
              <div class="text-center py-10 text-slate-400">
                No donors found matching your criteria.
              </div>
            }
          </div>
        </div>

        <!-- Donor Registration Form -->
        <div id="donorForm" class="lg:w-96">
          <div class="bg-white p-6 rounded-xl shadow-lg border border-slate-100 sticky top-24">
            <h3 class="text-xl font-bold text-slate-800 mb-4">Register as a Donor</h3>
            <p class="text-sm text-slate-500 mb-6">Fill up the form to be listed as a donor and help others in emergencies.</p>

            <form (submit)="onSubmit($event)" class="space-y-4">
              <div>
                <label class="block text-sm font-medium text-slate-700 mb-1">Full Name</label>
                <input type="text" [(ngModel)]="formData.name" name="name" class="w-full p-2.5 bg-white text-slate-900 border border-slate-300 rounded-lg focus:ring-brand-500 focus:outline-none placeholder-slate-400" required>
              </div>

              <div>
                <label class="block text-sm font-medium text-slate-700 mb-1">Blood Group</label>
                <select [(ngModel)]="formData.bloodGroup" name="bloodGroup" class="w-full p-2.5 bg-white text-slate-900 border border-slate-300 rounded-lg focus:ring-brand-500 focus:outline-none" required>
                   <option value="" disabled>Select Group</option>
                   <option value="A+">A+</option>
                   <option value="A-">A-</option>
                   <option value="B+">B+</option>
                   <option value="B-">B-</option>
                   <option value="O+">O+</option>
                   <option value="O-">O-</option>
                   <option value="AB+">AB+</option>
                   <option value="AB-">AB-</option>
                </select>
              </div>

              <div>
                <label class="block text-sm font-medium text-slate-700 mb-1">Phone Number</label>
                <input type="tel" [(ngModel)]="formData.phone" name="phone" class="w-full p-2.5 bg-white text-slate-900 border border-slate-300 rounded-lg focus:ring-brand-500 focus:outline-none placeholder-slate-400" required>
              </div>

              <div>
                <label class="block text-sm font-medium text-slate-700 mb-1">Location/Area</label>
                <input type="text" [(ngModel)]="formData.location" name="location" class="w-full p-2.5 bg-white text-slate-900 border border-slate-300 rounded-lg focus:ring-brand-500 focus:outline-none placeholder-slate-400" required>
              </div>

              <div class="flex items-start gap-2 pt-2">
                <input type="checkbox" required class="mt-1">
                <span class="text-xs text-slate-500">I agree to share my phone number and location publicly for blood donation purposes.</span>
              </div>

              <button class="w-full bg-medical-red text-white font-bold py-3 rounded-lg hover:bg-red-600 transition-colors shadow-md">
                Register Now
              </button>
            </form>
          </div>
        </div>

      </div>
    </div>
  `
})
export class BloodDonationPage {
  store = inject(StoreService);
  
  selectedGroup = signal('All');
  locationSearch = signal('');

  formData = {
    name: '',
    bloodGroup: '',
    phone: '',
    location: ''
  };

  get filteredDonors() {
    const list = this.store.bloodDonors();
    const group = this.selectedGroup();
    const loc = this.locationSearch().toLowerCase();

    return signal(list.filter(d => {
      const matchGroup = group === 'All' || d.bloodGroup === group;
      const matchLoc = !loc || d.location.toLowerCase().includes(loc);
      return matchGroup && matchLoc;
    }));
  }

  scrollToForm() {
    document.getElementById('donorForm')?.scrollIntoView({ behavior: 'smooth' });
  }

  onSubmit(e: Event) {
    e.preventDefault();
    if (this.formData.name && this.formData.bloodGroup && this.formData.phone) {
      this.store.registerDonor(this.formData);
      alert('Thank you! You have been registered as a donor.');
      this.formData = { name: '', bloodGroup: '', phone: '', location: '' };
    }
  }
}
