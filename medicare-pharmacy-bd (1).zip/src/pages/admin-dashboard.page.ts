
import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { StoreService, Order, Product } from '../services/store.service';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="min-h-screen bg-slate-100 flex flex-col md:flex-row">
      
      <!-- Sidebar -->
      <aside class="w-full md:w-64 bg-slate-800 text-white md:min-h-screen flex-shrink-0">
        <div class="p-6 border-b border-slate-700">
          <h2 class="text-xl font-bold">Admin Panel</h2>
          <p class="text-xs text-slate-400">Database Management</p>
        </div>
        <nav class="p-4 space-y-2">
          <button (click)="activeTab.set('orders')" [class.bg-slate-700]="activeTab() === 'orders'" class="w-full text-left px-4 py-3 rounded-lg hover:bg-slate-700 transition-colors flex items-center gap-3">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>
            Orders & Payments
          </button>
          <button (click)="activeTab.set('inventory')" [class.bg-slate-700]="activeTab() === 'inventory'" class="w-full text-left px-4 py-3 rounded-lg hover:bg-slate-700 transition-colors flex items-center gap-3">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" /></svg>
            Medicine Inventory
          </button>
          
          <div class="pt-4 mt-4 border-t border-slate-700">
             <button (click)="store.resetDatabase()" class="w-full text-left px-4 py-3 rounded-lg hover:bg-red-900/30 text-red-300 transition-colors flex items-center gap-3 text-sm">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
              Factory Reset DB
            </button>
          </div>

          <button (click)="logout()" class="w-full text-left px-4 py-3 rounded-lg hover:bg-red-900/50 text-red-100 transition-colors flex items-center gap-3 mt-4">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
            Sign Out
          </button>
        </nav>
      </aside>

      <!-- Main Content -->
      <main class="flex-1 p-6 overflow-y-auto">
        
        <!-- Orders Tab -->
        @if (activeTab() === 'orders') {
          <div class="space-y-6">
            <div class="flex justify-between items-center">
              <h1 class="text-2xl font-bold text-slate-800">Order Management</h1>
              <div class="bg-white px-4 py-2 rounded-lg shadow-sm text-sm font-medium text-slate-600">
                Total Orders: {{store.orders().length}}
              </div>
            </div>

            <!-- Pending Orders Alert -->
            @if (pendingCount > 0) {
              <div class="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-r-lg flex items-center justify-between">
                <div class="flex items-center gap-2">
                  <svg class="h-5 w-5 text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
                  <span class="text-yellow-800 font-bold">{{pendingCount}} orders waiting for payment confirmation.</span>
                </div>
              </div>
            }

            <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
              <div class="overflow-x-auto">
                <table class="w-full text-left text-sm text-slate-600">
                  <thead class="bg-slate-50 text-slate-800 uppercase font-bold border-b border-slate-200">
                    <tr>
                      <th class="px-6 py-4">Order ID</th>
                      <th class="px-6 py-4">Customer</th>
                      <th class="px-6 py-4">Total</th>
                      <th class="px-6 py-4">Payment</th>
                      <th class="px-6 py-4">Status</th>
                      <th class="px-6 py-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody class="divide-y divide-slate-100">
                    @for (order of store.orders(); track order.id) {
                      <tr class="hover:bg-slate-50 transition-colors">
                        <td class="px-6 py-4 font-mono font-bold">#{{order.id}}</td>
                        <td class="px-6 py-4">
                          <div class="font-bold text-slate-800">{{order.customerName}}</div>
                          <div class="text-xs text-slate-400">{{order.phone}}</div>
                          <div class="text-xs text-slate-400 truncate max-w-[150px]">{{order.address}}</div>
                        </td>
                        <td class="px-6 py-4 font-bold text-slate-800">৳{{order.totalAmount}}</td>
                        <td class="px-6 py-4">
                          <span class="uppercase text-xs font-bold px-2 py-1 rounded bg-slate-100 border border-slate-200">{{order.paymentMethod}}</span>
                          @if (order.transactionId) {
                            <div class="mt-1 text-xs font-mono text-blue-600 bg-blue-50 px-1 rounded inline-block">Trx: {{order.transactionId}}</div>
                          }
                          <div class="mt-1 text-[10px] text-slate-400">{{order.orderDate | date:'short'}}</div>
                        </td>
                        <td class="px-6 py-4">
                          <span class="px-3 py-1 rounded-full text-xs font-bold"
                            [class.bg-yellow-100]="order.status === 'pending'"
                            [class.text-yellow-700]="order.status === 'pending'"
                            [class.bg-blue-100]="order.status === 'confirmed'"
                            [class.text-blue-700]="order.status === 'confirmed'"
                            [class.bg-green-100]="order.status === 'delivered'"
                            [class.text-green-700]="order.status === 'delivered'"
                            [class.bg-red-100]="order.status === 'cancelled'"
                            [class.text-red-700]="order.status === 'cancelled'">
                            {{order.status | titlecase}}
                          </span>
                        </td>
                        <td class="px-6 py-4 text-right space-x-2">
                          @if (order.status === 'pending') {
                            <button (click)="updateStatus(order.id, 'confirmed')" class="text-blue-600 hover:text-blue-800 font-bold text-xs border border-blue-200 bg-blue-50 px-3 py-1.5 rounded hover:bg-blue-100 transition-colors">Confirm Pay</button>
                            <button (click)="updateStatus(order.id, 'cancelled')" class="text-red-600 hover:text-red-800 font-bold text-xs border border-red-200 bg-red-50 px-3 py-1.5 rounded hover:bg-red-100 transition-colors">Reject</button>
                          }
                          @if (order.status === 'confirmed') {
                            <button (click)="updateStatus(order.id, 'delivered')" class="text-green-600 hover:text-green-800 font-bold text-xs border border-green-200 bg-green-50 px-3 py-1.5 rounded hover:bg-green-100 transition-colors">Mark Delivered</button>
                          }
                        </td>
                      </tr>
                    }
                    @if (store.orders().length === 0) {
                      <tr>
                        <td colspan="6" class="px-6 py-12 text-center text-slate-400">No orders found in database.</td>
                      </tr>
                    }
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        }

        <!-- Inventory Tab -->
        @if (activeTab() === 'inventory') {
          <div class="space-y-6">
             <div class="flex justify-between items-center">
              <h1 class="text-2xl font-bold text-slate-800">Medicine Database</h1>
              <button (click)="showAddProduct.set(true)" class="bg-brand-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-brand-700 shadow-sm flex items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" /></svg>
                Add Medicine
              </button>
            </div>

            <!-- Add Product Form (Simple Inline) -->
            @if (showAddProduct()) {
              <div class="bg-white p-6 rounded-xl shadow-lg border border-brand-100 animate-fade-in-down mb-6">
                <h3 class="font-bold text-lg mb-4 text-brand-700">Add New Product</h3>
                <form (submit)="addProduct($event)" class="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <input required [(ngModel)]="newProduct.name" name="name" placeholder="Medicine Name" class="p-2 border rounded">
                  <select required [(ngModel)]="newProduct.category" name="category" class="p-2 border rounded">
                     <option value="Prescription Medicine">Prescription Medicine</option>
                     <option value="OTC Medicine">OTC Medicine</option>
                     <option value="Health Care">Health Care</option>
                     <option value="Baby Care">Baby Care</option>
                     <option value="Personal Care">Personal Care</option>
                  </select>
                  <input required type="number" [(ngModel)]="newProduct.price" name="price" placeholder="Price (BDT)" class="p-2 border rounded">
                  <input required [(ngModel)]="newProduct.brand" name="brand" placeholder="Brand/Manufacturer" class="p-2 border rounded">
                  <input [(ngModel)]="newProduct.image" name="image" placeholder="Image URL (https://...)" class="p-2 border rounded md:col-span-2">
                  <textarea [(ngModel)]="newProduct.description" name="desc" placeholder="Description" class="p-2 border rounded md:col-span-2"></textarea>
                  
                  <div class="flex items-center gap-4">
                    <label class="flex items-center gap-2 text-sm"><input type="checkbox" [(ngModel)]="newProduct.requiresPrescription" name="rx"> Prescription Required</label>
                  </div>

                  <div class="md:col-span-2 flex justify-end gap-3 mt-2">
                     <button type="button" (click)="showAddProduct.set(false)" class="px-4 py-2 text-slate-500 hover:text-slate-700">Cancel</button>
                     <button type="submit" class="bg-brand-600 text-white px-6 py-2 rounded font-bold hover:bg-brand-700">Save to DB</button>
                  </div>
                </form>
              </div>
            }

            <!-- Product List -->
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
               <table class="w-full text-left text-sm text-slate-600">
                  <thead class="bg-slate-50 text-slate-800 uppercase font-bold border-b border-slate-200">
                    <tr>
                      <th class="px-6 py-4">Image</th>
                      <th class="px-6 py-4">Name</th>
                      <th class="px-6 py-4">Category</th>
                      <th class="px-6 py-4">Price</th>
                      <th class="px-6 py-4">Stock</th>
                      <th class="px-6 py-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody class="divide-y divide-slate-100">
                     @for (product of store.products(); track product.id) {
                       <tr class="hover:bg-slate-50">
                         <td class="px-6 py-3">
                           <img [src]="product.image" class="w-10 h-10 rounded object-cover bg-gray-100">
                         </td>
                         <td class="px-6 py-3 font-medium text-slate-800">{{product.name}}</td>
                         <td class="px-6 py-3">{{product.category}}</td>
                         <td class="px-6 py-3 font-bold">৳{{product.price}}</td>
                         <td class="px-6 py-3">
                           @if (product.inStock) {
                             <span class="text-green-600 text-xs font-bold bg-green-50 px-2 py-1 rounded">In Stock</span>
                           } @else {
                             <span class="text-red-600 text-xs font-bold bg-red-50 px-2 py-1 rounded">Out of Stock</span>
                           }
                         </td>
                         <td class="px-6 py-3 text-right">
                           <button (click)="deleteProduct(product.id)" class="text-red-500 hover:text-red-700 hover:bg-red-50 p-2 rounded">
                             <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                           </button>
                         </td>
                       </tr>
                     }
                  </tbody>
               </table>
            </div>
          </div>
        }

      </main>
    </div>
  `
})
export class AdminDashboardPage {
  store = inject(StoreService);
  router = inject(Router);
  
  activeTab = signal<'orders' | 'inventory'>('orders');
  showAddProduct = signal(false);

  newProduct: any = {
    name: '',
    category: 'OTC Medicine',
    price: null,
    brand: '',
    image: '',
    description: '',
    requiresPrescription: false,
    inStock: true
  };

  get pendingCount() {
    return this.store.orders().filter(o => o.status === 'pending').length;
  }

  updateStatus(id: string, status: Order['status']) {
    this.store.updateOrderStatus(id, status);
  }

  addProduct(e: Event) {
    e.preventDefault();
    this.store.addProduct({
      ...this.newProduct,
      price: Number(this.newProduct.price),
      rating: 5,
      image: this.newProduct.image || 'https://picsum.photos/400/400'
    });
    this.showAddProduct.set(false);
    this.newProduct = { name: '', category: 'OTC Medicine', price: null, brand: '', image: '', description: '', requiresPrescription: false, inStock: true };
  }

  deleteProduct(id: string) {
    if(confirm('Are you sure you want to remove this item from the database?')) {
      this.store.deleteProduct(id);
    }
  }

  logout() {
    this.store.logout();
    this.router.navigate(['/']);
  }
}
