
import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { StoreService } from '../services/store.service';

@Component({
  selector: 'app-auth',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="bg-slate-100 min-h-screen flex items-center justify-center p-4">
      <div class="bg-white rounded-2xl shadow-2xl overflow-hidden w-full max-w-4xl min-h-[600px] relative flex flex-col md:flex-row">
        
        <!-- Forms Container -->
        <div class="w-full md:w-1/2 p-8 md:p-12 relative z-10 transition-all duration-700 ease-in-out" 
             [class.md:translate-x-full]="isSignUp()">
          
          <!-- Sign In Form -->
          <div class="absolute inset-0 p-12 flex flex-col justify-center transition-all duration-700"
               [class.opacity-0]="isSignUp()"
               [class.pointer-events-none]="isSignUp()"
               [class.opacity-100]="!isSignUp()">
            <form (submit)="onLogin($event)">
              <h1 class="text-3xl font-bold text-slate-800 mb-6 text-center">Sign In</h1>
              <div class="flex justify-center gap-4 mb-6">
                <button type="button" class="w-10 h-10 rounded-full border border-slate-300 flex items-center justify-center text-slate-600 hover:bg-slate-50">G</button>
                <button type="button" class="w-10 h-10 rounded-full border border-slate-300 flex items-center justify-center text-slate-600 hover:bg-slate-50">F</button>
              </div>
              <p class="text-center text-slate-500 mb-6 text-sm">or use your email account</p>
              
              <div class="space-y-4">
                <input type="email" placeholder="Email" class="w-full bg-slate-50 border-none p-3 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none" required>
                <input type="password" placeholder="Password" class="w-full bg-slate-50 border-none p-3 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none" required>
              </div>
              
              <a href="#" class="text-xs text-slate-500 mt-2 mb-8 block text-center hover:text-brand-600">Forgot your password?</a>
              
              <button class="w-full bg-brand-600 text-white font-bold py-3 rounded-full hover:bg-brand-700 transition-transform active:scale-95 shadow-lg">SIGN IN</button>
              
              <!-- Mobile Toggle -->
              <p class="mt-6 text-center text-sm md:hidden text-slate-600">
                New here? <button type="button" (click)="toggle()" class="text-brand-600 font-bold">Sign Up</button>
              </p>
            </form>
          </div>

          <!-- Sign Up Form -->
          <div class="absolute inset-0 p-12 flex flex-col justify-center transition-all duration-700"
               [class.opacity-0]="!isSignUp()"
               [class.pointer-events-none]="!isSignUp()"
               [class.opacity-100]="isSignUp()">
            <form (submit)="onSignup($event)">
              <h1 class="text-3xl font-bold text-slate-800 mb-6 text-center">Create Account</h1>
              <div class="flex justify-center gap-4 mb-6">
                <button type="button" class="w-10 h-10 rounded-full border border-slate-300 flex items-center justify-center text-slate-600 hover:bg-slate-50">G</button>
                <button type="button" class="w-10 h-10 rounded-full border border-slate-300 flex items-center justify-center text-slate-600 hover:bg-slate-50">F</button>
              </div>
              <p class="text-center text-slate-500 mb-6 text-sm">or use your email for registration</p>
              
              <div class="space-y-3">
                <input type="text" [(ngModel)]="signupData.name" name="name" placeholder="Full Name" class="w-full bg-slate-50 border-none p-3 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none" required>
                <input type="email" [(ngModel)]="signupData.email" name="email" placeholder="Email" class="w-full bg-slate-50 border-none p-3 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none" required>
                <input type="tel" [(ngModel)]="signupData.phone" name="phone" placeholder="Phone Number" class="w-full bg-slate-50 border-none p-3 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none" required>
                <input type="password" placeholder="Password" class="w-full bg-slate-50 border-none p-3 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none" required>
              </div>
              
              <button class="w-full mt-8 bg-brand-600 text-white font-bold py-3 rounded-full hover:bg-brand-700 transition-transform active:scale-95 shadow-lg">SIGN UP</button>

              <!-- Mobile Toggle -->
              <p class="mt-6 text-center text-sm md:hidden text-slate-600">
                Already registered? <button type="button" (click)="toggle()" class="text-brand-600 font-bold">Sign In</button>
              </p>
            </form>
          </div>
        </div>

        <!-- Overlay / Banner Side (Desktop Only) -->
        <div class="hidden md:flex absolute top-0 left-0 h-full w-1/2 bg-gradient-to-r from-brand-600 to-brand-500 text-white transition-transform duration-700 ease-in-out z-20"
             [class.translate-x-full]="!isSignUp()">
           
           <!-- Overlay Content: Sign Up Prompt (Visible when showing Sign In Form) -->
           <div class="absolute inset-0 flex flex-col items-center justify-center text-center p-12 transition-transform duration-700"
                [class.-translate-x-[20%]]="isSignUp()">
              <h1 class="text-4xl font-bold mb-4">Hello, Friend!</h1>
              <p class="mb-8 text-brand-100">Enter your personal details and start your health journey with us.</p>
              <button (click)="toggle()" class="border-2 border-white text-white font-bold py-2 px-12 rounded-full hover:bg-white hover:text-brand-600 transition-colors">SIGN UP</button>
           </div>

           <!-- Overlay Content: Sign In Prompt (Visible when showing Sign Up Form) -->
           <div class="absolute inset-0 flex flex-col items-center justify-center text-center p-12 transition-transform duration-700"
                [class.translate-x-[20%]]="!isSignUp()"
                [class.opacity-0]="!isSignUp()">
              <h1 class="text-4xl font-bold mb-4">Welcome Back!</h1>
              <p class="mb-8 text-brand-100">To keep connected with us please login with your personal info.</p>
              <button (click)="toggle()" class="border-2 border-white text-white font-bold py-2 px-12 rounded-full hover:bg-white hover:text-brand-600 transition-colors">SIGN IN</button>
           </div>
        </div>

      </div>
    </div>
  `
})
export class AuthPage {
  store = inject(StoreService);
  router = inject(Router);
  
  isSignUp = signal(false);
  
  signupData = {
    name: '',
    email: '',
    phone: ''
  };

  toggle() {
    this.isSignUp.update(v => !v);
  }

  onLogin(e: Event) {
    e.preventDefault();
    // Simulate Login
    this.store.login({
      id: '123',
      name: 'Demo User',
      email: 'user@example.com',
      phone: '01700000000',
      address: 'Dhaka, Bangladesh',
      image: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Felix'
    });
    this.router.navigate(['/profile']);
  }

  onSignup(e: Event) {
    e.preventDefault();
    // Simulate Register
    this.store.login({
      id: Date.now().toString(),
      name: this.signupData.name,
      email: this.signupData.email,
      phone: this.signupData.phone,
      address: '',
      image: `https://api.dicebear.com/7.x/avataaars/svg?seed=${this.signupData.name}`
    });
    this.router.navigate(['/profile']);
  }
}
