
import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { StoreService } from '../services/store.service';

@Component({
  selector: 'app-admin-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div class="bg-white rounded-xl shadow-2xl w-full max-w-md p-8">
        
        <div class="text-center mb-8">
          <div class="inline-block p-3 bg-slate-100 rounded-full mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-slate-800" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
          </div>
          <h1 class="text-2xl font-bold text-slate-800">Admin Portal</h1>
          <p class="text-slate-500 text-sm mt-1">MediCare Pharmacy BD Database System</p>
        </div>

        <form (submit)="onLogin($event)" class="space-y-6">
          <div>
            <label class="block text-sm font-bold text-slate-700 mb-1">Admin Email</label>
            <input type="email" [(ngModel)]="email" name="email" class="w-full p-3 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:outline-none" placeholder="admin@medicare.bd" required>
          </div>

          <div>
            <label class="block text-sm font-bold text-slate-700 mb-1">Password</label>
            <input type="password" [(ngModel)]="password" name="password" class="w-full p-3 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:outline-none" placeholder="••••••••" required>
          </div>

          @if (error()) {
            <div class="bg-red-50 text-red-600 text-sm p-3 rounded-lg flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              {{error()}}
            </div>
          }

          <button class="w-full bg-slate-800 text-white font-bold py-3 rounded-lg hover:bg-slate-900 transition-colors shadow-lg">
            Access Database
          </button>
        </form>

        <div class="mt-6 text-center text-xs text-slate-400">
          <p>Restricted Access. Authorized Personnel Only.</p>
          <p>Demo Creds: admin@medicare.bd / 123456</p>
        </div>
      </div>
    </div>
  `
})
export class AdminLoginPage {
  store = inject(StoreService);
  router = inject(Router);

  email = '';
  password = '';
  error = signal('');

  onLogin(e: Event) {
    e.preventDefault();
    // Hardcoded demo credentials
    if (this.email === 'admin@medicare.bd' && this.password === '123456') {
      this.store.loginAdmin();
      this.router.navigate(['/admin/dashboard']);
    } else {
      this.error.set('Invalid credentials. Access Denied.');
    }
  }
}
